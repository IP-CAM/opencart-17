<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']       = 'معلومات';

// Text
$_['text_module']         = 'الموديولات';
$_['text_success']        = 'تم التعديل!';
$_['text_edit']        = 'Edit Information Module';

// Entry

$_['entry_status']        = 'الحالة:';


// Error
$_['error_permission']    = 'تحذير: أنت لا تمتلك صلاحيات التعديل!';
